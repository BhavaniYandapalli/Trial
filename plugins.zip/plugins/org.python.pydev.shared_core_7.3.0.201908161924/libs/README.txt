Note: lucene-core-6.1.0 is actually org.apache.lucene.core_6.1.0.v20170628-1158.jar from http://download.eclipse.org/tools/orbit/I-builds/I20170628123958/repository

Which has a fix for https://www.brainwy.com/tracker/PyDev/826